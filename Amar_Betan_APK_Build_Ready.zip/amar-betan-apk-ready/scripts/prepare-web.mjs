import { cp, mkdir, rm } from 'node:fs/promises';

await rm('dist', { recursive: true, force: true });
await mkdir('dist', { recursive: true });

const files = [
  'index.html',
  'style.css',
  'app.js',
  'manifest.webmanifest',
  'sw.js'
];

for (const file of files) {
  await cp(file, `dist/${file}`);
}
